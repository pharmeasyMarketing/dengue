import { DengueResearchPage } from '@/components/DengueResearch/DengueResearchPage';

const Index = () => {
  return <DengueResearchPage />;
};

export default Index;
